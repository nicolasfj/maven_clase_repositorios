package com.politecnicomalaga.strategy;

public class PonerCaraDePena implements SelectorDeseoInterface {

    @Override
    public String elegirDeseo(String deseo) {
        return "pone cara de pena y decir a un adulto " + deseo;
    }
}
