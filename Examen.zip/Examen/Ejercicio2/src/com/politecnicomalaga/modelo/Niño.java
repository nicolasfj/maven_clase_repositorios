package com.politecnicomalaga.modelo;

public class Niño {
    private String nombre;
    private String deseo;

    public Niño(String nombre, String deseo){
        this.nombre = nombre;
        this.deseo = deseo;
    }

    public Niño(String deseo) {
        this.deseo = deseo;
    }

    public void setDeseo(String deseo){
        this.deseo = deseo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDeseo() {
        return deseo;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Niño{" +
                "nombre='" + nombre + '\'' +
                ", deseo='" + deseo + '\'' +
                '}';
    }
}
